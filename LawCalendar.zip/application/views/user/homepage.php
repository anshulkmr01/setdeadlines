<!DOCTYPE html>
<html>
<head>
	<title>title</title>
	<!-- Global Css using Helper -->
	<?php 
			globalCss(); 
	?>
	<!--/ Global Css using Helper -->
</head>
<body>
	<!-- Navbar -->
		<?php include 'navbar.php'?>
	<!--/ Navbar -->

	<div class="container-fluid categories-home">
		<div class="container">
			Hello Users
		</div>
	</div>
</body>
	<?php 
			globalJs(); 
	?>
</html>
