
$().ready(function () {
    /* You would normally put this in a seperate file */
    $('.sortable-table').tableSorter();
});
